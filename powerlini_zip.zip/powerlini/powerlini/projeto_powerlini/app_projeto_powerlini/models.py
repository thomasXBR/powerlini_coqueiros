from django.db import models

class Projetos(models.Model):
    id_projeto = models.AutoField(primary_key=True)
    nome_projeto = models.TextField(max_length=255)

class Trainees(models.Model):
    id_trainee = models.AutoField(primary_key=True)
    nome_trainee = models.TextField(max_length=255)

class Usuario(models.Model):
    id_usuario = models.AutoField(primary_key=True)
    nome_usuario = models.TextField(max_length=255)
    email_usuario = models.TextField(max_length=255)
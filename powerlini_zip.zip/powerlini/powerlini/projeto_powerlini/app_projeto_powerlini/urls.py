from django.urls import path
# from ..projeto_powerlini import views

urlpatterns = [
    # path('', views.user_login, name='login'),
    # path('cadastro/', views.user_cadastro, name='cadastro'),
]
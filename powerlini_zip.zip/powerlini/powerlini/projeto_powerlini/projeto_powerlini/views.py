from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User

def user_login(request):
    if request.method == 'GET':
        return render(request, 'login.html')
    else:
        email = request.POST.get('email')
        senha = request.POST.get('senha')
        return HttpResponse(email)

def user_cadastro(request): 
    if request.method == 'GET':
        return render(request, 'cadastro.html')
    else:
        nome = request.POST.get('nome')
        email = request.POST.get('email')
        senha = request.POST.get('senha')
        
        user = User.objects.filter(email=email).first()

        if user:
            return HttpResponse('Esse email já está cadastrado')
        
        user = User.objects.create_user(username=nome, email=email, password=senha)
        user.save()

        return HttpResponse('Usuário cadastrado com sucesso')

def pagina_principal(request):
    return render(request, 'pagina_principal.html')
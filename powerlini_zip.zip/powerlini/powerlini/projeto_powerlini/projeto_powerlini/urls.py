from django.contrib import admin
from django.urls import path, include
from . import views  # Import views from app_projeto_powerlini

urlpatterns = [
    path('admin/', admin.site.urls),
    path('auth/', include('app_projeto_powerlini.urls')),
    path('', views.user_login, name='login'),
    path('cadastro/', views.user_cadastro, name='cadastro'),
    path('pagina_principal/', views.pagina_principal, name='pagina_principal'),
]